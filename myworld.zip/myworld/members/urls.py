from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('login',views.login,name='login'),
    path('car',views.car,name='car'),
    path('home',views.home,name='home'),
    path('personal',views.personal,name='personal'),
    path('medical',views.medical,name='medical'),
    path('education',views.education,name='education'),
    path('cal',views.cal,name='cal'),
    path('pal',views.pal,name='pal'),
    
    
]