from django.shortcuts import render
from django.http import HttpResponse
import math

def index(request):
    return render(request,'home.html')
def login(request):
    return render(request,'typeloan.html')
def car(request):
    return render(request,'car.html')
def home(request):
    return render(request,'homei.html')
def personal(request):
    return render(request,'personal.html')
def medical(request):
    return render(request,'health.html')
def education(request):
    return render(request,'education.html')
def pal(request):
    ki=request.POST.get('inx', None)
    avail=0
    if(ki==11.00):
        avail=56
    elif(ki==02.15):
        avail=68
    elif(ki==06.00):
        avail=10
    else:
        avail=45
    return render(request,'pal.html',{'result':ki,'result2':int(avail)})
def cal(request):
    p=int(request.GET["in"])
    if(p==5):
        k="A"
        j=2
    elif(p==6):
        k="B"
        j=1
    elif(p==10):
        k="C"
        j=5
    else:
        j=3
        k="D"
    res=p
    s=""
    for i in range(p*2):
        if(i%2==0):
            s+=k+str(j)
            j+=1
        else:
            s+=","
    res2=s
    res3="CONFIRMED"
    return render(request,'result.html',{'result':int(res),'result2':str(res2),'result3':str(res3)})
    